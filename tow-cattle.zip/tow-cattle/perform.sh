#! /bin/bash

/usr/local/apache-jmeter-5.0/bin/jmeter -n -r -t $1  -j jmeter.log  -l $1.jtl -e -o report/ 
